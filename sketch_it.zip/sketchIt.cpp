//	MTE 1A Final Project - 2D Plotter
//	Simeng Yang, Jeremy Afoke, Zong Xu, Sarthak Tamboli
//	Outputs to data.txt

#include <cmath> 
#include <fstream> 
#include <sstream>
using namespace std; 
#include "ccc_win.h"

//	Draws a shape inputs by the user and writes coordinates of user-created 
//	points to an external text file
void drawShape(ofstream &fout, ostringstream &convert, double width, double height){
	//	Max size of the array
	const int ASIZE = 25;
	Point points[ASIZE];
	bool keepGoing = true;
	bool inputMode = true;
	int count = 0;
	int state = 0;
	double x = -1000, y = -1000;
	string coord;
    
    cwin << Message(Point(width / 2 - 4, height - 4), "Toggle input method with the space-bar.")
		 << Message(Point(width / 2 - 4, height - 3), "Right-click mouse before your last point!")
         << Message(Point(width / 2 - 2, height - 2), "MAX # PTS = 25");
        
	while (keepGoing && count < ASIZE) {
		//	Toggle input method (true -> mouse input; false -> keyboard input)
		if (GetAsyncKeyState(VK_SPACE)){
			inputMode = !inputMode;
		}
		//	Output mode for either a point or a line connecting two points
		//	True by default (connects points to form a line)
		state = 0;
		//	Keyboard input
		if (!inputMode){
			//	Fetches x and y
			//	Must check bounds to ensure points are within the paper
			do{
				x = cwin.get_double("X, >= 0 AND <= width: ");
				y = cwin.get_double("Y, >= 0 AND <= height: ");
				state = cwin.get_int("Z, 0 - Lowered or 1 - Lifted");
				//	While inputs are invalid / out of bounds
			} while (!(x >= 0 && x <= width) || !(y >= 0 && y <= height) || !(state == 0 || state == 1));
			points[count] = Point(x, y);
		}
		//	Mouse input
		else
			points[count] = cwin.get_mouse("");
			
		//	Last point before termination
		if (GetAsyncKeyState(VK_RBUTTON))
			keepGoing = false;
		//	Point can be defined to be above surface when middle mouse button
		//	is pressed and for the initial point
		else if (GetAsyncKeyState(VK_MBUTTON) || count == 0){
			//	1 is when the pen is lifted
			state = 1;
		}
			
		if (state == 1){
			//	Only draw point
			cwin << points[count];
		}
		else{
			if (count == 0)
				cwin << points[0];
			else{
				//	Draw line
				cwin << Line(points[count - 1], points[count]);
			}	
		}

		//	Determines x and y coordinates of points
        x = round(points[count].get_x() * 100) / 100;
        y = round(points[count].get_y() * 100) / 100;
        
        //	Converts coordinates from double to string for outputting
		convert.str("");
		convert.clear();
		convert << count << ": " << x << ", " << y; 
 		coord = convert.str();
 		
		//	Output data to text file
		fout << x << " " << y << " " << state << endl;
		cwin << Message(Point(points[count].get_x() + 0.1, points[count].get_y() + 0.1), coord);
		count++;
	};
}

//	Basis for a regular polygon, centered at (x,y)
//	with a radial distance from the centre of rSize and rSides sides
//	Optional angle can be specified to rotate shape about centre
void drawPoly(ofstream &fout, ostringstream &convert, double width, double height, double rAngle = 0){
	//	Most many-sided polygon is decagon with 10 sides
	const int MAXSIDES = 10;
	double x = width / 2;
	double y = height / 2;
	//	Minimum dimension between width and height
	//	Set boundary for polygon radial distance; must be constrained within the minimum dimension
	double minDim;
	if (x < y)
		minDim = x;
	else
		minDim = y;
	double maxSize = (minDim  * 0.9);
	int rSides;
	double rSize;
    //	Converts coordinates from double to string for outputting
	convert << "Enter the radial distance from the centre (<= " << maxSize << "): "; 
 	string radDist = convert.str();
	
	//	Gets no. of sides
	do
		rSides = cwin.get_int("Enter the no. of sides (<= 10): ");
	while(rSides > MAXSIDES);
	//	Gets radial distance
	do 
		rSize = cwin.get_double(radDist);
	while (rSize > maxSize);
	
    //	Assume maximum number of points (or lines) is 10 (decagon)
	Point points[MAXSIDES + 1];
	double nX, nY;
	
	//	Define x and y for all points
	//	Degrees are simpler to work with, although radians can be used also
	//	Rounds to more appropriate degree of precision; floor and ceiling can both be used
	//	more or less interchangeably, as the difference in the rounding will be negigible
	for (int l = 0; l <= rSides; l++){
		nX = round((x + rSize * cos((225 + rAngle + (360 / rSides) * l) 
						  / 180.0 * M_PI)) * pow(10, 2)) / pow(10, 2);
		nY = round((y + rSize * sin((45 + rAngle + (360 / rSides) * l) 
						  / 180.0 * M_PI)) * pow(10, 2)) / pow(10, 2);
		points[l] = Point(nX, nY);
		//	Output data to text files
		fout << nX << " " << nY << " ";
		//	First point should be defined above
		if (l == 0)
			fout << "1" << endl;
		else
			fout << "0" << endl;
	}
	
	//	Define lines with start and end points; output lines to console window
	for (int k = 0; k < rSides; k++){
		cwin << Line(points[k%(rSides+1)], points[(k+1)%(rSides+1)]);
	}
}

//	Draws rectangle centered at (x, y), with given dimensions
void drawRect(double x, double y, double xMag, double yMag){
	cwin << Line(Point(x - xMag / 2, y + yMag / 2), 
			Point(x + xMag / 2, y + yMag / 2))
	     << Line(Point(x + xMag / 2, y + yMag / 2), 
		 	Point(x + xMag / 2, y - yMag / 2))
	     << Line(Point(x + xMag / 2, y - yMag / 2), 
		 	Point(x - xMag / 2, y - yMag / 2))
	     << Line(Point(x - xMag / 2, y - yMag / 2), 
		    Point(x - xMag / 2, y + yMag / 2));
}

int ccc_win_main() {
	//	Output files
	ofstream fout("data.txt");
	ostringstream convert; 
	//	Maximum horizontal distance (width), determined mechanical design of robot
	const double XMAX = 15;
	//	Length of gap that should be left from end of paper for stable drawing
	const double YTOL = 5;
	//	Set window dimensions
	double xL = 0, yT = 0;
	//	Ensure drawing window is the same size as dimensions for machine
	//	Note that horizontal drawing length is only 15 cm
	double xR = cwin.get_double("X paper size: ");
	//	If distance is too great, change it to the upper bound
	if (xR > XMAX)
		xR = XMAX;
	double yB = cwin.get_double("Y paper size: ") - YTOL;
	cwin.coord(xL, yT, xR, yB);
	//	Drawing a rectangle for a light drawing border
	drawRect(xR / 2, yB / 2, xR, yB);
	int uChoice = cwin.get_int("Draw a predetermined polygon (0) or draw a custom shape (!0)? ");
	if (uChoice == 0)
		//	Note: Polygon may appear compressed due to window sizing.
		//	This will not distort the drawing on the robot when fed input.
		drawPoly(fout, convert, xR, yB);
	else
		drawShape(fout, convert, xR, yB);
	//	Close output files
	fout.close();
	return 0;
}
